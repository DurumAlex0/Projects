package separarclases;

public class Info {
	
	public static void informacionClases (String[] args) {
		
		 System.out.println("\nNuestras clases son:");
         System.out.println("---------------------------");
         System.out.println("Desarrollo de Aplicaciones Multiplataforma");
         System.out.println("Auxiliar de Enfermería");
         System.out.println("Higiene Bucodental");
         System.out.println("Actividades Comerciales");
         System.out.println("Administración de Sistemas Informáticos en Redes");      
         System.out.println("Marketing y Publicidad");
         System.out.println("Sistemas Microinformáticos y Redes");
         System.out.println("Comercio Internacional");
         System.out.println("Gestión Administrativa");
         System.out.println("---------------------------");
		
	}
	public static void informacionSobreNosotros (String[] args) {
		
		System.out.println("\nSobre nosotros:");
        System.out.println("--------------------------------------------------");
        System.out.println("En FP Pro2 somos un grupo de estudiantes comprometidos con la innovación,");
        System.out.println("la tecnología y el aprendizaje práctico.");
        System.out.println("Nuestro objetivo es aplicar los conocimientos adquiridos en clase a proyectos reales,");    
        System.out.println("desarrollando soluciones útiles, creativas y eficientes.");
        System.out.println("--------------------------------------------------");
		
	}
	public static void informacionContacto (String[] args) {
		
        System.out.println("---------------------------");
        System.out.println("Teléfono: 636 31 84 13");
        System.out.println("---------------------------"); 
				
	}
}	
	


