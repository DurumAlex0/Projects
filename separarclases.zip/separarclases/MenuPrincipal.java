package separarclases;

public class MenuPrincipal {

    public static void mostrar() {
        System.out.println("\n--- Menú Principal ---");
        System.out.println("1 - Alumnado");
        System.out.println("2 - Profesores");
        System.out.println("3 - Clases");
        System.out.println("4 - Sobre nosotros");
        System.out.println("5 - Contacto");
        System.out.println("6 - Salir");
        System.out.println("7 - Ver Hora");
        System.out.println("8 - Minijuego");
        System.out.print("Opción: ");
    }
}