package separarclases;

import java.util.ArrayList;
import java.util.Scanner;

import static separarclases.Colores.*;

public class Main {

    public static void main(String[] args) {
    	

        Scanner sc = new Scanner(System.in);

    	System.out.println("\n---------------------------");
    	System.out.println(GREEN + "\t\nBIENVENIDO A PRO2FP!" + RESET);
    	System.out.println("\n---------------------------");

        String nombre = Utilidades.pedirNombre(sc, "Nombre");
        String apellido = Utilidades.pedirNombre(sc, "Apellido");
        int edad = Utilidades.pedirEdad(sc);

        if (edad < 18) {
            System.out.println(RED + "Debes ser mayor de edad." + RESET);
            return;
        }

        System.out.println("Hola " + GREEN + nombre + " " + apellido + RESET);
        
        

        ArrayList<String> alumnos = new ArrayList<>();
        boolean ejecutando = true;

        while (ejecutando) {

            MenuPrincipal.mostrar();
            int opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    MenuAlumnos.mostrar(sc, alumnos, nombre);
                    Utilidades.esperar(sc);
                    break;

                case 2:
                    MenuProfes.mostrar(sc);
                    Utilidades.esperar(sc);
                    break;

                case 3:
                    System.out.println("Clases disponibles...");
                    Info.informacionClases(args);
                    Utilidades.esperar(sc);
                    break;

                case 4:
                    System.out.println("Sobre nosotros...");
                    Info.informacionSobreNosotros(args);
                    Utilidades.esperar(sc);
                    break;

                case 5:
                    System.out.println("Contáctanos...");
                    Info.informacionContacto(args);
                    Utilidades.esperar(sc);
                    break;

                case 6:
                    System.out.println("Saliendo...");
                    ejecutando = false;
                    break;

                case 7:
                    Utilidades.mostrarHora();
                    Utilidades.esperar(sc);
                    break;

                case 8:
                    Utilidades.miniJuego(sc);
                    Utilidades.esperar(sc);
                    break;

                default:
                    System.out.println(RED + "Opción inválida." + RESET);
            }
        }

        sc.close();
    }
}