package separarclases;

import java.util.ArrayList;
import java.util.Scanner;

import static separarclases.Colores.*;

public class MenuAlumnos {

    public static void mostrar(Scanner sc, ArrayList<String> alumnos, String userName) {

        System.out.println("\n--- Gestión de Alumnos ---");
        System.out.println("1 - Añadir alumno");
        System.out.println("2 - Ver lista");
        System.out.println("3 - Sorpresa");
        System.out.print("Elige una opción: ");

        int opcion = sc.nextInt();
        sc.nextLine();

        switch (opcion) {
            case 1:
                System.out.print("Nombre del alumno: ");
                String nuevo = sc.nextLine();
                alumnos.add(nuevo);
                System.out.println(GREEN + "Alumno añadido." + RESET);
                break;

            case 2:
                System.out.println("Lista de alumnos:");
                System.out.println(alumnos);
                break;

            case 3:
                System.out.println(GREEN + "PLEASE " + userName + " I NEED THIS..." + RESET);
                break;

            default:
                System.out.println(RED + "Opción inválida." + RESET);
        }
    }
}
