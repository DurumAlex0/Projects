package separarclases;

//IMPORTS NECESARIOS PARA ESTA CLASE
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

//IMPORTAR LOS COLORES ANSI DE LA OTRA
import static separarclases.Colores.*;

public class Utilidades {
	
	public static String pedirNombre(Scanner sc, String etiqueta) {
        System.out.print(etiqueta + ": ");
        String nombre = sc.nextLine();

        while (nombre.matches(".*\\d.*") || nombre.trim().isEmpty()) { 
            System.out.println(RED + "Por favor, introduce un nombre válido." + RESET);
            System.out.print(etiqueta + ": ");
            nombre = sc.nextLine();
        }
        return nombre;
    }

    public static int pedirEdad(Scanner sc) {
        System.out.print("Edad: ");

        while (!sc.hasNextInt()) {
            System.out.println(RED + "Introduce un número válido." + RESET);
            sc.nextLine();
        }

        int edad = sc.nextInt();
        sc.nextLine();
        return edad;
    }

    public static void mostrarHora() {
        LocalTime time = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        System.out.println("La hora actual es: " + time.format(formatter));
    }

    public static void miniJuego(Scanner sc) {
        int random = (int)(Math.random() * 10) + 1;

        System.out.println("\nAdivina el número entre 1 y 10:");
        int guess = sc.nextInt();
        sc.nextLine();

        if (guess == random) {
            System.out.println("¡Correcto!");
        } else {
            System.out.println("Incorrecto, era: " + random);
        }
    }

    public static void esperar(Scanner sc) {
        System.out.print(GREEN + "\nPresiona Enter para volver..." + RESET);
        sc.nextLine();
    }
    
}







