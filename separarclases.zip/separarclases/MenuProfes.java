package separarclases;

import java.util.Scanner;

public class MenuProfes {

    private static final String[] nombres = {
            "Eustaquio", "Facundo", "Rigoberto", "Mario", "Dolores", "Jorge"};

    private static final String[] clases = {
            "Desarrollo Multiplataforma",
            "Auxiliar de Enfermería",
            "Higiene Bucodental",
            "Actividades Comerciales",
            "Administración de Sistemas",
            "Marketing y Publicidad"
    };

    public static void mostrar(Scanner sc) {

        System.out.println("\n--- Gestión de Profesores ---");
        System.out.println("1 - Ver profesores");
        System.out.println("2 - Ver especialidades");
        System.out.print("Elige una opción: ");

        int opcion = sc.nextInt();
        sc.nextLine();

        switch (opcion) {
            case 1:
                for (String n : nombres) System.out.println(n);
                break;

            case 2:
                for (int i = 0; i < nombres.length; i++) {
                    System.out.println (nombres[i] + ": " + clases[i]);
                }
                break;

            default:
                System.out.println("Opción inválida.");
        }
    }
}